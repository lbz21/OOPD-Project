
maven surefire is configured so that files in folders with 
*manual in class path are not run by surefire