package org.solent.com528.project.model.service;

import org.solent.com528.project.model.dto.ReplyMessage;

public class RestService {

    public ReplyMessage open

}
