package org.solent.com528.project.model.service;

import java.lang.System.Logger;
import java.sql.Date;
import java.util.logging.LogManager;

public interface GatesEntry {

    public boolean opentheGate(TicketMachine ticketMachine, String zonesTravelled, Date currentTime);

}

public class GatesEntryImpl implements GatesEntry {

    final static Logger LOG = LogManager.addLogger(GateEntryServiceImpl.class);

    private String publicKeyFileOnClasspath = null;

    public void GateEntryServiceImpl(String publicKeyFileOnClasspath) {
        this.publicKeyFileOnClasspath = publicKeyFileOnClasspath;
    }

}

    @Override
    public boolean opentheGate(TicketMachine ticket, String zonesTravelledStr, Date currentTime) {
        ((Object) LOG).debug("openGate called with zonesTravelled= " + zonesTravelledStr + "ticket=" + ticket);

    }

    long validFromMs = TicketMachine.getValidFrom().getTime();
    long validToMs = TicketMachine.getValidTo().getTime();

    private java.util.Date currentTime;
    long currentTimeMs = currentTime.getTime();
}
