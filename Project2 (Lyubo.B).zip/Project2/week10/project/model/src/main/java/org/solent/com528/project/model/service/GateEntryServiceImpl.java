package org.solent.com528.project.model.service;

public class GateEntryServiceImpl {

}
