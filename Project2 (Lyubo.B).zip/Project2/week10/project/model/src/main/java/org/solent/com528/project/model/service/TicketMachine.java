//my own ticket machine model
package org.solent.com528.project.model.service;

import java.io.StringReader;
import java.io.StringWriter;
import java.sql.Date;
import java.time.format.DateTimeFormatter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

public class TicketMachine {

    private static final TicketMachine TicketMachine = null;

	private static final String TicketMachineXML = null;

    // this is the price of the printed ticket from this machine
    private int Price;

    private int Balance;

    private String zonesTravelled; // zones travelled

    private String StartingStations;

    private String KeyEncoded;

    private int Total;

    private String zones;

    @XmlElement(name = "validFrom")
    @XmlJavaTypeAdapter(DateTimeFormatter.class)
    private static Date validFrom;

    @XmlElement(name = "validTo")
    @XmlJavaTypeAdapter(DateTimeFormatter.class)
    private static Date validTo;

    // returning all the content, everything but without the encoded key.

    public String getContent() {
        return "TicketMachine{" + "zonesTravelled" + zonesTravelled + ",StartingStations=" + StartingStations
                + "validFrom=" + validFrom + ",validTo=" + validTo + '}';

    }

    public String getzonesTravelled() {
        return zonesTravelled;
    }

    public void setzones(String zones) {
        this.zones = zonesTravelled;
    }

    public String getKeyEncoded() {
        return KeyEncoded;
    }

    public void setEncryptedKey(String encryptedkey) {
        this.KeyEncoded = encryptedkey;
    }

    public static Date getValidFrom() {
        return validFrom;

    }

    public void setValidFrom(Date validFrom) {
        TicketMachine.validFrom = validFrom;
    }

    public static Date getValidTo() {
        return validTo;
    }

    public void setValidTo(Date validTo) {
        this.validTo = validTo;
    }

    public String getStartingStations() {
        return StartingStations;
    }

    public void setStartingStations(String StartingStations) {
        this.StartingStations = StartingStations;
    }

    // can add further details into it//

    // this below is my constructor class

    public TicketMachine(int ticketCost) {

        Price = ticketCost;
        Balance = 0;
        Total = 0;

    }

    // next I have added the methods, which have take the role of implementing the
    // behaviour of the objects.

    public int getPrice() {

        return Price;
    }

    public int getBalance() {
        return Balance;

    }

    public void insertMoney(int Amount) {
        Balance = Balance + Amount;
    }

    // the purpose of the code below is to simulate the printing of the ticket to
    // the user
    public void printTicket() {
        System.out.println("###################");
        System.out.println("###################");
        System.out.println(" # Here's your ticket");
        System.out.println("#" + Price + "coins.");
        System.out.println("###################");
        System.out.println("");

        Total = Total + Balance; // this is to update the total amount together with the balance

        // clear the balance

        Balance = 0;

    }

public static TicketMachine fromXML(String TicketMachineXML) {
    JAXBContext jaxbContext = JAXBContext.newInstance("org.solent.com528.project.impl.dao.jaxb;");
    Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();

    TicketMachine ticketMachine = (TicketMachine) jaxbUnMarshaller.unmarshal(new StringReader(TicketMachineXML));
    return TicketMachine;
    
}
catch(

    Exception e)
    {
        throw new IllegalArgumentException(
                "The ticke machine was unable to marshall, please restart and try again in a little bit" + TicketMachineXML);

    }

    public String toXML() {

        try {
            JAXBContext jaxbContext = JAXBContext.newInstance("org.solent.com528.project.impl.dao.jaxb;");
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

            StringWriter sw1 = new StringWriter();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            jaxbMarshaller.marshal(this, sw1);
            return sw1.toString();
        }

        catch (Exception ex) {
            throw new RuntimeException("There is an issue with the marshalling ticket, please try again", ex);
        }

    }

}
