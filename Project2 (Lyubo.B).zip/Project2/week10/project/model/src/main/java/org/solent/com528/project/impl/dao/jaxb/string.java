package org.solent.com528.project.impl.dao.jaxb;

public class string {

}
