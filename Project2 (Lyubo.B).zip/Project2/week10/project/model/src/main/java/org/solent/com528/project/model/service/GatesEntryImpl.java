package org.solent.com528.project.model.service;

import java.sql.Date;

public class GatesEntryImpl implements GatesEntry {

    @Override
    public boolean opentheGate(TicketMachine ticketMachine, String zonesTravelled, Date currentTime) {
        // TODO Auto-generated method stub
        return false;
    }

}
