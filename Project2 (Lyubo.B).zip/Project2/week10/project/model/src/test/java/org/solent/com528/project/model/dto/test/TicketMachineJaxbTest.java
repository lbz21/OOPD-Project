package org.solent.com528.project.model.dto.test;

public class TicketMachineJaxbTest {

}
