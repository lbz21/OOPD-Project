package org.solent.com528.project.impl.rest;

public class TicketSampleRest {

}
